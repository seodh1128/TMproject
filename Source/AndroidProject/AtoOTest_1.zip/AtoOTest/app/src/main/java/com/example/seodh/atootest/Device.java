package com.example.seodh.atootest;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by SeoDH on 2017-11-29.
 */
// Device.java
// Retrofit2로 송/수신할 모델 클래스

public class Device implements Serializable{
    // 변수 : DB 컬럼(IoT시스템 전반에서 송/수신할 Data)을 기준으로 선정 - Web/Arduino/Android 공통요소
    private long deviceId;
    private String deviceType;
    private String deviceCode;
    private double deviceValue;
    private Date deviceTime;

    public Device() {
    }

    public Device(String deviceType, String deviceCode, double deviceValue, Date deviceTime) {
        super();
        this.deviceType = deviceType;
        this.deviceCode = deviceCode;
        this.deviceValue = deviceValue;
        this.deviceTime = deviceTime;
    }

    public long getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(long deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceName(String deviceName) {
        this.deviceCode = deviceName;
    }

    public double getDeviceValue() {
        return deviceValue;
    }

    public void setDeviceValue(double deviceValue) {
        this.deviceValue = deviceValue;
    }

    public Date getDeviceTime() {
        return deviceTime;
    }

    public void setDeviceTime(Date deviceTime) {
        this.deviceTime = deviceTime;
    }

    @Override
    public String toString() {
        return "Device [deviceId=" + deviceId + ", deviceType=" + deviceType + ", deviceCode=" + deviceCode
                + ", deviceValue=" + deviceValue + ", deviceTime=" + deviceTime + "]";
    }

//    static Device parseJson(String jsonString) {
//        JsonParser parser = new JsonParser();
//        JsonElement element = parser.parse(jsonString);
//        JsonObject jObj = element.getAsJsonObject();
//
//        String type = jObj.get("type").getAsString();
//        String name = jObj.get("name").getAsString();
//        int pinNumber = jObj.get("pinNumber").getAsInt();
//
//        Sensor sonsor = new Sensor(type, name, pinNumber);
//        sonsor.setValue(jObj.get("value").getAsDouble());
//        sonsor.setTime(new Date(jObj.get("time").getAsLong()));
//
//        return sonsor;
//    }

}
