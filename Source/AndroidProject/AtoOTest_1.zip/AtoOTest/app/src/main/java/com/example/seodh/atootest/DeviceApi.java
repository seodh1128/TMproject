package com.example.seodh.atootest;

import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Created by SeoDH on 2017-11-29.
 */

public interface DeviceApi {

    //public static final String API_URL ="http://192.168.110.10:8090/iot/api/";

    @GET("device/")
    Call<List<Device>> listDev();//

    @GET("device/{id}")
    Call<Device> get(@Path("id") long id);

    @POST("device/")
        //Call<Device> insert(@Body Device device);
    Call<Boolean> insert(@Body Device device);

    public static final Retrofit retrofit = new Retrofit.Builder()
            .baseUrl("http://192.168.110.10:8090/iot/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();

}
